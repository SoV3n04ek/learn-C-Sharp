﻿using System;
using System.Data.SqlClient;

namespace SQL_CRUD_AdoNet
{
    class SqlConnectionModel : ISqlConnectionModel
    {
        public string server   { get; set; }
        public string database { get; set; }

        public string connectionString;

        private SqlConnection connection;

        public SqlConnectionModel(string _server, string _database)
        {
            server           = _server;
            database         = _database;
            connectionString = $"Server={server};Database={database};Trusted_Connection=True;";
            connection       = new SqlConnection();
        }
        
        public void connect()
        {
            connectionString = $"Server={server};Database={database};Trusted_Connection=True;";
    
            connection = new SqlConnection(connectionString);

            try { connection.Open(); }
            catch(InvalidOperationException e)
            {
                throw new Exception(e.Message);
            }
            catch(SqlException e)
            {
                throw new Exception(e.Message);
            }
        }

        public int Add(string name, bool isFruit, string color, int colories)
        {
            int affectedRows = -1;

            SqlCommand command = GetInsertCommand(connection, name, isFruit, color, colories);
            affectedRows = command.ExecuteNonQuery();

            return affectedRows;
        }

        public int Delete(int id)
        {
            int affectedRows = -1;
            
            SqlCommand command = GetDeleteCommand(connection, id);
            affectedRows = command.ExecuteNonQuery();
            
            return affectedRows;
        }

        public int Edit(string name, bool isFruit, string color, int colories, int id) 
        {
            int affectedRows = -1;

            SqlCommand command = GetUpdateCommand(connection, name, isFruit, color, colories, id);
            affectedRows = command.ExecuteNonQuery();

            return affectedRows;

        }

        public SqlDataReader Select()
        {
            SqlCommand command = GetSelectCommand(connection);

            SqlDataReader reader = command.ExecuteReader();
            
            if (reader.Read())
                return reader;
            else
                throw new Exception("Reader have nothing");
        }

        private SqlCommand GetInsertCommand(SqlConnection connection, string name, bool isFruit, string color, int colories)
        {
            SqlCommand command = connection.CreateCommand();

            command.CommandText =
                $"INSERT INTO VegetablesAndFruits (IsFruit, Color, Calories, Name)" +
                $"  VALUES (@isFruit, @color, @calories, @name)";

            command.Parameters.AddWithValue("name", name);
            command.Parameters.AddWithValue("isFruit", isFruit);
            command.Parameters.AddWithValue("color", color);
            command.Parameters.AddWithValue("calories", colories);

            return command;
        }

        private SqlCommand GetSelectCommand(SqlConnection connection)
        {
            SqlCommand command = connection.CreateCommand();

            command.CommandText =
                $"SELECT * FROM VegetablesAndFruits";

            return command;
        }

        private SqlCommand GetDeleteCommand(SqlConnection connection, int id)
        {
            SqlCommand command = connection.CreateCommand();

            command.CommandText =
                $"DELETE FROM VegetablesAndFruits WHERE Id = {id}";

            return command;
        }

        private SqlCommand GetUpdateCommand(SqlConnection connection, string name, bool isFruit, string color, int colories, int id)
        {
            SqlCommand command = connection.CreateCommand();

            command.CommandText = $"UPDATE VegetablesAndFruits " +
                $"SET IsFruit = @isFruit, Color = @color, Calories = @calories, Name = @name WHERE Id = {id}";

            command.Parameters.AddWithValue("name", name);
            command.Parameters.AddWithValue("isFruit", isFruit);
            command.Parameters.AddWithValue("color", color);
            command.Parameters.AddWithValue("calories", colories);

            return command;
        }
    }
}
