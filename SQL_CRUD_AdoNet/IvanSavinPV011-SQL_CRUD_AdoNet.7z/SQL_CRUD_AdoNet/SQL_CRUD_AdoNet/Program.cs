﻿using System;
using System.Data.SqlClient;
using SQL_CRUD_AdoNet;

var server = @"(localdb)\MSSQLLocalDB";
var database = "VegetablesAndFruits";

//var connectionString = $"Server={server};Database={database};Trusted_Connection=True;";

SqlConnectionModel sqlcm = new SqlConnectionModel(server, database);

try 
{ 
    sqlcm.connect();
}
catch(Exception e)
{
    Console.WriteLine(e.Message);
}

Console.WriteLine("Successful connected");

bool appLoop = true;
do 
{
    View.RenderMenu();

    int answer = 0;

    do 
    {
        answer = Controller.GetMenuAnswer();
    } while (answer > 5 && answer < 1);

    DatabaseRecord record;
    int id;
    int affectedRows;
    switch (answer)
    {

        case View.ADD:
            record = Controller.GetDatabaseRecordFromUser();
            sqlcm.Add(record.name, record.isFruit, record.color, record.calories);
            
            break;
        case View.EDIT:
            Console.WriteLine("Enter id to edit record: ");
            id = Controller.GetIdFromUser();
            record = Controller.GetDatabaseRecordFromUser();
            
            affectedRows = sqlcm.Edit(record.name, record.isFruit, record.color, record.calories, id);
            Console.WriteLine($"affected rows = {affectedRows}");
            
            break;
        case View.SHOW:
            SqlDataReader sqldata = null;

            try
            {
                sqldata = sqlcm.Select();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                View.RenderTable(sqldata);
            }

            break;
        case View.DELETE:
            Console.WriteLine("Enter id to delete record: ");
            id = Controller.GetIdFromUser();
            affectedRows = sqlcm.Delete(id);
            Console.WriteLine($"affected rows = {affectedRows}");
            
            break;
        case View.QUIT:
            appLoop = false;
            break;
    }

} while (appLoop);