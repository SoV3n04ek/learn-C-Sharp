﻿using System.Data.SqlClient;

namespace SQL_CRUD_AdoNet
{
    internal class View
    {
        public const int ADD = 1,
            EDIT = 2,
            DELETE = 3,
            SHOW = 4,
            QUIT = 5;

        public static void RenderTable(SqlDataReader sqldata)
        {
            if (sqldata != null)
            {
                Console.WriteLine("\n================================================");
                Console.WriteLine("Id | Name | IsFruit | Color | Calories");

                while (sqldata.Read())
                {
                    string result = sqldata["Id"].ToString() + " | " +
                        sqldata["Name"].ToString() + " | " +
                        sqldata["IsFruit"].ToString() + " | " +
                        sqldata["Color"].ToString() + " | " +
                        sqldata["Calories"].ToString();

                    Console.WriteLine(result);
                }
                sqldata.Close();
                Console.WriteLine("================================================\n");
            }
        }

        public static void RenderMenu()
        {
            Console.WriteLine("================================================");
            Console.WriteLine("1 - Add a new record to the database");
            Console.WriteLine("2 - Edit record in database");
            Console.WriteLine("3 - Delete record in database");
            Console.WriteLine("4 - Show database");
            Console.WriteLine("5 - Quit");
            Console.WriteLine("Choose a number from 1 to 5");
        }
    }
}
